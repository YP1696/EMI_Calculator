export interface emiResult{
    emi:string;
    interest:string;
    total: string;
    loanAmt: string;
  }